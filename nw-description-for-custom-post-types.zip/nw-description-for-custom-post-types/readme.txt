=== NW Description For Custom Post Types ===
Contributors: NAKWEB
Tags: description, meta, custom post type, nakweb, nw
Requires at least: 4.9.13
Tested up to: 5.3.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Requires PHP: 7.0

== Description ==


* WPコアの投稿タイプおよびカスタム投稿タイプのアーカイブページ、シングルページのメタディスクリプションを設定できます。
* メタディスクリプションは</head>の直前に自動的に挿入されます。

* アーカイブページ用メタディスクリプションの優先度
     1. プラグインの設定内容
     2. ウェブサイトのキャッチフレーズ

* シングルページ用メタディスクリプションの優先度
     1. 記事の本文から抜粋
     2. プラグインの設定内容
     3. ウェブサイトのキャッチフレーズ

* NW系プラグインについて
     * 本プラグイン以外にもNW系として複数のプラグインを作成しています。
     * すべてのNW系プラグインの設定画面は同一のトップレベルメニューのサブメニューとして追加されます。
     * トップレベルメニューのラベルはプラグイン上で変更が可能です。


== Installation ==

1. From the WP admin panel, click “Plugins” -> “Add new”.
2. In the browser input box, type “NW Description For Custom Post Types”.
3. Select the “NW Description For Custom Post Types” plugin and click “Install”.
4. Activate the plugin.

OR…

1. Download the plugin from this page.
2. Save the .zip file to a location on your computer.
3. Open the WP admin panel, and click “Plugins” -> “Add new”.
4. Click “upload”.. then browse to the .zip file downloaded from this page.
5. Click “Install”.. and then “Activate plugin”.


== Frequently asked questions ==



== Screenshots ==



== Changelog ==



== Upgrade notice ==



== Arbitrary section 1 ==
