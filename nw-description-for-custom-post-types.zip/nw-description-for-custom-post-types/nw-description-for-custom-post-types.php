<?php
/*
 * Plugin Name: NW Description For Custom Post Types
 * Description: カスタム投稿タイプのアーカイブページおよびシングルページのディスクリプションを設定できます。
 * Version: 1.0.0
 * Author: Nakweb
 * Author URI: https://www.nakweb.com/
 * License: GPLv2 or later
 */

// Exit if accessed directly.
if (!defined('ABSPATH')) {
     exit;
}

register_activation_hook(__FILE__, array('NW_Description_For_Custom_Post_Types', 'myplugin_activation'));
register_uninstall_hook(__FILE__, array('NW_Description_For_Custom_Post_Types', 'myplugin_uninstall'));

class NW_Description_For_Custom_Post_Types
{
     /**
      * prefix
      */
     const PREFIX = 'nw_dfcpt_';

     /**
      * ui version
      */
     const UI_VERSION = '1.0.0';

     /**
      * option_name in wp_options
      */
     const OPTION_NAME = 'nw_description_for_custom_post_types_options';

     /**
      * common option_name in wp_options
      */
     const COMMON_NAME = 'nw_common_options';

     /**
      * name hidden type
      */
     const HIDDEN_NAME = 'submit_hidden';

     /**
      * __construct
      */
     public function __construct()
     {
          add_action('plugins_loaded', array($this, 'plugins_loaded'));
     }

     /**
      * Loading translation files.
      */
     public function plugins_loaded()
     {
          if (!class_exists('NW_Common_Menu')) {
               // NW_Common_Menu class is containd in all plugin created by NAKWEB.
               require_once plugin_dir_path(__FILE__) . 'common/class.common.php';
          }
          add_action('admin_menu', array($this, 'add_nw_sub_menu'), 99);
          add_action('wp_head', array($this, 'insert_meta_description'), 99);
     }

     /**
      * Add sub menu page.
      */
     public function add_nw_sub_menu()
     {
          if (current_user_can('administrator') || current_user_can('editor')) {
               $parent_slug = NW_Common_Menu::SLUG;
               $capability = 'edit_pages';   // Only Administrator and Editor can run.
               $add_page = add_submenu_page($parent_slug, 'ディスクリプション設定', 'ディスクリプション設定', $capability, 'nw_dfcpt_settings', array($this, 'settings_page'));

               add_action('admin_print_styles-' . $add_page, array($this, 'register_css_files'));
               add_action('admin_print_scripts-' . $add_page, array($this, 'register_js_files'));
          }
     }

     /**
      * Register style sheets.
      */
     public function register_css_files()
     {
          wp_register_style(self::PREFIX . 'settings', plugin_dir_url(__FILE__) . 'css/settings.css', array(), self::UI_VERSION);
     }

     /**
      * Register java script.
      */
     public function register_js_files()
     {
          wp_register_script(self::PREFIX . 'counter', plugin_dir_url(__FILE__) . 'js/counter.js', array(), self::UI_VERSION, true);
          wp_register_script(self::PREFIX . 'toggle', plugin_dir_url(__FILE__) . 'js/toggle.js', array(), self::UI_VERSION, true);
     }

     /**
      * Display settings page.
      */
     public function settings_page()
     {
          // Administrator and Editor can run.
          if (!current_user_can('edit_pages')) {
               wp_die(__('You do not have sufficient permissions to access this page.'));
          }

          self::enqueue_files();

          $descriptions = self::genarate_array();

          if (isset($_POST[self::HIDDEN_NAME]) && $_POST[self::HIDDEN_NAME] == 'Y') :

               check_admin_referer(self::PREFIX . 'field', self::PREFIX . 'field_nonce');

               self::update_descriptions($descriptions);
               ?>
               <div class="updated">
                    <p><strong>設定を保存しました。</strong></p>
               </div>

          <?php endif; ?>

          <div class="wrap">
               <h1>ディスクリプション設定</h1>
               <form id="description" name="<?php echo self::PREFIX ?>form" method="post" action="">
                    <input type="hidden" name="<?php echo self::HIDDEN_NAME ?>" value="Y">
                    <?php foreach ($descriptions as $key => $value) : ?>
                         <?php $label = get_post_type_object($key)->label ?>
                         <dl class="register_description">
                              <dt id="<?php echo $key  . '_term' ?>" class="trigger"><?php echo $label ?></dt>
                              <dd class="contents">
                                   <div class="archdes">
                                        <label>アーカイブ(一覧)</label>
                                        <div class="inputBox">
                                             <textarea class="str_counter" name="<?php echo $key . '_archive_field' ?>"><?php echo esc_html(stripslashes($value[0])) ?></textarea>
                                             <div class="counter"><span class="show-count">0</span>文字</div>
                                        </div>
                                   </div>
                                   <div class="singdes">
                                        <label>シングル（詳細）</label>
                                        <div class="inputBox">
                                             <textarea class="str_counter" name="<?php echo $key . '_single_field' ?>"><?php echo esc_html(stripslashes($value[1])) ?></textarea>
                                             <div class="counter"><span class="show-count">0</span>文字</div>
                                        </div>
                                   </div>
                              </dd>
                         </dl>
                    <?php endforeach; ?>
                    <p class="submit"><input id="submit_btn" type="submit" name="Submit" class="button-primary" value="変更を保存" /></p>
                    <?php wp_nonce_field(self::PREFIX . 'field', self::PREFIX . 'field_nonce'); ?>
               </form>
          </div>

<?php
     }

     /**
      * Insert <meta name="description"> into wp_head.
      */
     public function insert_meta_description()
     {
          global $post;
          if (is_single() || is_archive()) {

               $slug = get_post_type();

               if ($slug && get_option(self::OPTION_NAME)) {
                    $options = get_option(self::OPTION_NAME);
                    $option = $options[$slug];
               }

               if (is_single()) {
                    // single page
                    $description = $post->post_content;
                    if (empty($description) && isset($option)) {
                         $description = esc_html($option[1]);
                    }
               } else {
                    // archive page
                    if (isset($option)) {
                         $description = esc_html($option[0]);
                    }
               }

               if (empty($description)) {
                    $description = get_bloginfo('description');
               }

               $description = str_replace(array("\r\n", "\r", "\n", "&nbsp;"), '', $description);
               $description = preg_replace('/\[.*\]/', '', $description);
               $description = wp_strip_all_tags($description);
               $description = mb_strimwidth($description, 0, 320, "...");
               echo '<meta name="description" content="' . esc_attr($description) . '">';
          }
     }

     /**
      * Set descripsions from db or initialize.
      */
     public function genarate_array()
     {
          $initial_array = self::get_initial_array();

          if (get_option(self::OPTION_NAME)) {
               $options = get_option(self::OPTION_NAME);

               foreach ($initial_array as $key => &$value) {
                    if (isset($options[$key])) {
                         $value[0] = $options[$key][0];
                         $value[1] = $options[$key][1];
                    }
               }
               unset($value);
          }

          return $initial_array;
     }

     /**
      * Get default array.
      */
     public function get_initial_array()
     {
          $custom_post_types = self::get_custom_post_types();

          $initial_array = array();
          foreach ($custom_post_types as $custom_post_type) {
               $initial_array[$custom_post_type] = array('', '');
          }
          return $initial_array;
     }

     /**
      * Update descriptions.
      *
      * @param array &$descriptions
      */
     public function update_descriptions(&$descriptions)
     {
          foreach ($descriptions as $key => &$value) {
               $value[0] = sanitize_text_field($_POST[$key . '_archive_field']);
               $value[1] = sanitize_text_field($_POST[$key . '_single_field']);
          }
          unset($value);

          update_option(self::OPTION_NAME,  $descriptions);
     }

     /**
      * Get custom post type objects.
      *
      * @return array
      */
     public function get_custom_post_types()
     {
          $args = array(
               'public' => true,
               '_builtin' => false
          );
          $cpt_objects = get_post_types($args, 'objects');

          return self::get_slug_list($cpt_objects);
     }

     /**
      * Get custom post type's slug list.
      *
      * @param array $objects
      * @return array
      */
     public function get_slug_list($objects)
     {
          $slug_list = array('post');
          foreach ($objects as $object) {
               array_push($slug_list, $object->name);
          }
          return $slug_list;
     }

     /**
      * Load any files.
      */
     public function enqueue_files()
     {
          wp_enqueue_style(self::PREFIX . 'settings');
          wp_enqueue_script('jquery');
          wp_enqueue_script(self::PREFIX . 'counter');
          wp_enqueue_script(self::PREFIX . 'toggle');
     }

     /**
      * Activation
      */
     public static function myplugin_activation()
     {
          self::activation_common();
     }

     /**
      * Uninstall
      */
     public static function myplugin_uninstall()
     {
          self::uninstall_common();

          $result = get_option(self::OPTION_NAME);
          if ($result) {
               delete_option(self::OPTION_NAME);
          }
     }

     /**
      * Register nw-ish plugin activated at least once.
      */
     public function activation_common()
     {
          $myplugin_name = plugin_basename(__FILE__);
          $myplugin_name = explode('/', $myplugin_name)[0];
          $option_value = get_option(self::COMMON_NAME);
          if (!empty($option_value)) {
               $flg = 0;
               if (!empty($option_value['list'])) {
                    foreach ($option_value['list'] as $plugin) {
                         if ($plugin === $myplugin_name) {
                              $flg = 1;
                              break;
                         }
                    }
               }
               if (!$flg) {
                    array_push($option_value['list'], $myplugin_name);
               }
          } else {
               $option_value['label'] = '';
               $option_value['list'] = array($myplugin_name);
          }
          update_option(self::COMMON_NAME, $option_value);
     }

     /**
      * Delete common option from wp_options.
      */
     public function uninstall_common()
     {
          // Get nw-ish plugins activated at least once.
          $nw_plugins = get_option(self::COMMON_NAME)['list'];
          if (empty($nw_plugins)) {
               return;
          }

          // Get nw-ish plugins installed.
          $installed_plugins = scandir(WP_PLUGIN_DIR);
          $prefix = 'nw-';
          $flg = 0;
          if ($installed_plugins) {
               foreach ($installed_plugins as $installed_plugin) {
                    if (!strncmp($installed_plugin, $prefix, 3)) {
                         foreach ($nw_plugins as $nw_plugin) {
                              if ($installed_plugin === $nw_plugin) {
                                   if ($flg) {
                                        // Exist NW-ish plugins two or more.
                                        $flg++;
                                   } else {
                                        // Exist NW-ish plugin.
                                        $flg = 1;
                                   }
                                   break;
                              }
                         }
                         if ($flg >= 2) {
                              break;
                         }
                    }
               }
          }
          if ($flg < 2) {
               // Uninstall last nw-ish plugin.
               $result = get_option(self::COMMON_NAME);
               if ($result) {
                    delete_option(self::COMMON_NAME);
               }
          }
     }
}
new NW_Description_For_Custom_Post_Types();
